/*
    Faculty level.
 */
public enum FacultyLeve {
    AS,
    AO,
    FU
}
