public interface EmployeeInfo {
    int FACULTY_MONTHLY_SALARY = 5000;
    int STAFF_MONTHLY_HOURS_WORKED = 160;
}
